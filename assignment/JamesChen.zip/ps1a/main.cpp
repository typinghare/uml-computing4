// Copyright 2024 James Chan
#include <iostream>

int main() {
    std::cout << "This is the main function in main.cpp" << std::endl;

    return 0;
}
