# PS6: RandWriter

## Contact

> Name: Zhuojian Chen (James)
>
> Student ID: 02151380
>
> Section: COMP 2040 P 1 203
>
> Time to Complete: Apr 3, 2024

## Description

Explain what the project does.

### Features

Describe what your major decisions were and why you did things that way.

### Testing

What tests did you write? What exceptions did you use? Does your code pass the tests?

### Lambda

What does your lambda expression do? What function did you pass it to?

### Issues

What did you have trouble with? What did you learn? What doesn't work? Be honest. You might be penalized if you claim something works and it doesn't.

### Extra Credit

Anything special you did. This is required to earn bonus points.

## Acknowledgements

List all sources of help including the instructor or TAs, classmates, and web pages.
